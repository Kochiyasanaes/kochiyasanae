package Encoder;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

import org.codehaus.jackson.map.ObjectMapper;


public class EncoderClassVo implements Encoder.Text<Map<String, String>>{

    @Override
    public void init(EndpointConfig config) {
        // TODO Auto-generated method stub

    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub

    }
//����web�˴��ݵ���Map���͵�
    @Override
    public String encode(Map<String, String> map) throws EncodeException {
        ObjectMapper    mapMapper= new ObjectMapper();
        try {
            String json="";
            json=mapMapper.writeValueAsString(map);
            return  json;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "false";
        }
    }
//����㴫�ݵ���һ���࣬��ʹ������д��
//    @Override  
//    public String encode(Person person) throws EncodeException {  
//        try {  
//            return Java2Json.JavaToJson(person, false);  
//        } catch (MapperException e) {  
//            // TODO Auto-generated catch block  
//            e.printStackTrace();  
//            return null;  
//        }  
//    }  

}