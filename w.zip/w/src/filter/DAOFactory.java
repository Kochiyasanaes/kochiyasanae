package filter;

import dao.ChatUserDao;
import interfac.ChatUserinterface;

public class DAOFactory {
	 
	
	public static ChatUserinterface createUserDaoImp()
	    {
	        return new ChatUserDao();
	    }
}
