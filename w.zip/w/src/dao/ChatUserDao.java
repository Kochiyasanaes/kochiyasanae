package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import filter.DAOException;
import interfac.ChatUserinterface;
import util.DBUtil;

public class ChatUserDao implements ChatUserinterface{
	public ChatUserDao() {
		
	}
	//�����������
	public void createChatUser(String account)throws DAOException{
	 String sql = "insert into tb_chatuser(username)value(?)";
	 Connection conn = null;
     PreparedStatement ps = null;
     
     
     int i = 0;
     try
     {
         conn = DBUtil.getConnection();
         //�����Ҫ�������ݿ��Զ����ɵ��ֶ�ֵ
//         ps = conn.prepareStatement(sql);
           ps = (PreparedStatement) conn.prepareStatement(sql);
           ps.setString(1, account);
	        i = ps.executeUpdate();
         
  
//         EBPLogger.debug(ps.toString());
        
         //�ӽ�����л�ȡ���ݿ��Զ����ɵ��ֶ�ֵ
         
     }
     catch (SQLException e)
     {
         e.printStackTrace();
     }
     finally
     {
         DBUtil.close(conn, ps);
     }
    
  }
	
	//�����Ƿ��Ѿ��������������
	public  int findChatUser(String account)throws DAOException{
		 String sql = "select count(*) from tb_chatuser where username=?";
	        // TODO Auto-generated method stub
	        Connection conn = null; 
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        int reS = 0;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setString(1, account);
	          
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeQuery();
	          
	   			 
	   		 
	          if(rs.next()) {
	        	  reS = rs.getInt(1);
	          } 
	          
	          if (reS == 0) {
	            	//������
					reS = 1;
				}else {
					//����
					reS = -1;
				}
	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps,rs);
	        }
	        
	        return reS;
	}

	public void insertMessage(String account,String message,String time)throws DAOException{
		 String sql = "insert into tb_messageSave(username,text,time)value(?,?,?)";
		 Connection conn = null;
	     PreparedStatement ps = null;
	     
	     
	     int i = 0;
	     try
	     {
	         conn = DBUtil.getConnection();
	         //�����Ҫ�������ݿ��Զ����ɵ��ֶ�ֵ
//	         ps = conn.prepareStatement(sql);
	          ps = (PreparedStatement) conn.prepareStatement(sql);
	          ps.setString(1, account);
	          ps.setString(2, message);
	          ps.setString(3, time);
		        i = ps.executeUpdate();
	         
	  
//	         EBPLogger.debug(ps.toString());
	        
	         //�ӽ�����л�ȡ���ݿ��Զ����ɵ��ֶ�ֵ
	         
	     }
	     catch (SQLException e)
	     {
	         e.printStackTrace();
	     }
	     finally
	     {
	         DBUtil.close(conn, ps);
	     }
	}

	//��Ϣ����������Ϣ��
	public void insertLiXianMessage(int fid,int gid,String message)throws DAOException{
		 String sql = "insert into tb_lixianmessage(fid,gid,message)value(?,?,?)";
		 Connection conn = null;
	     PreparedStatement ps = null;
	     
	     
	     int i = 0;
	     try
	     {
	         conn = DBUtil.getConnection();
	         //�����Ҫ�������ݿ��Զ����ɵ��ֶ�ֵ
//	         ps = conn.prepareStatement(sql);
	          ps = (PreparedStatement) conn.prepareStatement(sql);
	          ps.setInt(1, fid);
	          ps.setInt(2, gid);
	          ps.setString(3, message);
		        i = ps.executeUpdate();
	         
	  
//	         EBPLogger.debug(ps.toString());
	        
	         //�ӽ�����л�ȡ���ݿ��Զ����ɵ��ֶ�ֵ
	         
	     }
	     catch (SQLException e)
	     {
	         e.printStackTrace();
	     }
	     finally
	     {
	         DBUtil.close(conn, ps);
	     }
	}
    //�ж��Ƿ����
	public int findLixianMessage(int gid)throws DAOException{
		 String sql = "select count(*) from tb_lixianmessage where gid=?";
	        // TODO Auto-generated method stub
	        Connection conn = null; 
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        int reS = 0;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1, gid);
	          
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeQuery();
	          
	   			 
	   		 
	          if(rs.next()) {
	        	  reS = rs.getInt(1);
	          } 
	          
	          if (reS == 0) {
	            	//������
					reS = -1;
				}else {
					//����
					reS = 1;
				}
	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps,rs);
	        }
	        
	        return reS;
	}
	//��ȡ������Ϣ
	public String getLixianMessage(int gid)throws DAOException{
	  	String sql = "SELECT GROUP_CONCAT(fid,message SEPARATOR  \"/\") AS rmessage FROM tb_lixianmessage WHERE gid = ?";
    	
 	   Connection conn = null; 
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String message = null;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1, gid);
//	            ps.setString(2,password);
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeQuery();
	           
	            if(rs.next())
	            {
	                message = rs.getString(1);
	                
	            }

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps,rs);
	        }
 	
 	
 	
 	
 	
 	return message;
	}
    //����֮������ɾ�����ݿ�������Ϣ
	public void removeLiXianMessage(int gid)throws DAOException{
		 
		    int i = 0;
		    String sql = "DELETE FROM tb_lixianmessage WHERE gid =  ?";
				
		    Connection conn = null; 
	        PreparedStatement ps = null;
	        int rs = 0;
	        String message = null;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1, gid);
//	            ps.setString(2,password);
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeUpdate();
	           
	        

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps);
	        }
	}

	//ע�����������Ҷ���
	public void deleteChatUser(String account)throws DAOException{
		  int i = 0;
		    String sql = "DELETE FROM tb_chatuser WHERE username =  ?";
				
		    Connection conn = null; 
	        PreparedStatement ps = null;
	        int rs = 0;
	        String message = null;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setString(1, account);
//	            ps.setString(2,password);
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeUpdate();
	           
	        

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps);
	        }
	}
    //�õ��������ߵ�id
	public String getChatUserId()throws DAOException{
		    String sql = "SELECT GROUP_CONCAT(username SEPARATOR  \"/\") AS rmessage FROM tb_chatuser";
		    Connection conn = null; 
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String message = null;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            
//	            ps.setString(2,password);
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeQuery();
	           
	            if(rs.next())
	            {
	                message = rs.getString(1);
	                
	            }

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps,rs);
	        }
		
	return message;	
	}
	//�����غ��ѵ�id
	public String gethaoyouliebaoid(int account)throws DAOException{
    	String sql = "SELECT fid FROM tb_haoyouliebiao WHERE uid = ?";
    	
    	   Connection conn = null; 
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String fid = null;
	        try
	        {
	            conn = DBUtil.getConnection();
	            ps = conn.prepareStatement(sql);
	            ps.setInt(1, account);
//	            ps.setString(2,password);
//	            EBPLogger.debug(ps.toString());
	            rs = ps.executeQuery();
	           
	            if(rs.next())
	            {
	                fid = rs.getString(1);
	                
	            }

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DBUtil.close(conn, ps,rs);
	        }
    	
    	return fid;
    }
	//�������߱��޸��û�����״̬
	 public void updatazaixain(int uid)throws DAOException{
		  String sql = "update tb_Information set stautus= 1 where id = ?";
	        Connection conn = null;
	        PreparedStatement ps = null;
	        int i = 0;
	        try
	        {
	            conn = DBUtil.getConnection();
	            //�����Ҫ�������ݿ��Զ����ɵ��ֶ�ֵ
//	            ps = conn.prepareStatement(sql);
	            ps = (PreparedStatement) conn.prepareStatement(sql);
	            ps.setInt(1, uid);
		        i = ps.executeUpdate();
	            
	     
//	            EBPLogger.debug(ps.toString());
	           
	            //�ӽ�����л�ȡ���ݿ��Զ����ɵ��ֶ�ֵ
	            
	        }
	        catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        finally
	        {
	            DBUtil.close(conn, ps);
	        }
	 }
	 
	 //����֮���Զ�������״̬��Ϊ����
		 public void updatalixian(int uid)throws DAOException{
			  String sql = "update tb_Information set stautus= -1 where id = ?";
		        Connection conn = null;
		        PreparedStatement ps = null;
		        int i = 0;
		        try
		        {
		            conn = DBUtil.getConnection();
		            //�����Ҫ�������ݿ��Զ����ɵ��ֶ�ֵ
//		            ps = conn.prepareStatement(sql);
		            ps = (PreparedStatement) conn.prepareStatement(sql);
		            ps.setInt(1, uid);
			        i = ps.executeUpdate();
		            
		     
//		            EBPLogger.debug(ps.toString());
		           
		            //�ӽ�����л�ȡ���ݿ��Զ����ɵ��ֶ�ֵ
		            
		        }
		        catch (SQLException e)
		        {
		            e.printStackTrace();
		        }
		        finally
		        {
		            DBUtil.close(conn, ps);
		        }
		 }
	
}
