package filter;

public class DAOException extends Exception{

	private int errorCode;
    private String msg;
    public DAOException(int errorCode, String msg)
    {
        this.errorCode = errorCode;
        this.msg=msg;
    }    
}
