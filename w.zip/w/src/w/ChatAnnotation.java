package w;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.sun.javafx.collections.MappingChange.Map;

import Encoder.EncoderClassVo;
import filter.DAOException;
import guanli.ChatUserMvc;
 
//��ע������ָ��һ��URI���ͻ��˿���ͨ�����URI�����ӵ�WebSocket������Servlet��ע��mapping��������web.xml�����á�
@ServerEndpoint(value="/websocket/{userId}",encoders = { EncoderClassVo.class })
public class ChatAnnotation {
    //��̬������������¼��ǰ������������Ӧ�ð�����Ƴ��̰߳�ȫ�ġ�
    private static int onlineCount = 0;
     
    //concurrent�����̰߳�ȫSet���������ÿ���ͻ��˶�Ӧ��MyWebSocket������Ҫʵ�ַ�����뵥һ�ͻ���ͨ�ŵĻ�������ʹ��Map����ţ�����Key����Ϊ�û���ʶ
    private static CopyOnWriteArraySet<ChatAnnotation> webSocketSet = new CopyOnWriteArraySet<ChatAnnotation>();
     
//    private static ConcurrentHashMap<String, Session> clients =new ConcurrentHashMap<String,Session>();
    
    //��ĳ���ͻ��˵����ӻỰ����Ҫͨ���������ͻ��˷�������
    private Session session;
    private String nickname;  
    private String haoyouname; 
    
    
    
    
    private static final String GUEST_PREFIX = "Guest";  
    private static final AtomicInteger connectionIds = new AtomicInteger(0);  
    private int i;
    /**
     * ���ӽ����ɹ����õķ���
     * @param session  ��ѡ�Ĳ�����sessionΪ��ĳ���ͻ��˵����ӻỰ����Ҫͨ���������ͻ��˷�������
     */
   
    
    public ChatAnnotation() {  
    	 i = connectionIds.getAndIncrement();
        
        System.out.println("ֵΪ��    "+i);
    }  
    
    @OnOpen
    public void onOpen(@PathParam("userId") String relationId,Session session) throws IOException, DAOException, NumberFormatException, EncodeException{
    	

    	if (ChatUserMvc.getInstance().findChatUser(relationId) == 1) {
    		
    		System.out.println("����ɹ�");
    		ChatUserMvc.getInstance().insertChatAccount(relationId);
		}else {
			System.out.println("����ʧ��");
		}
    	ChatUserMvc.getInstance().updatazaixain(Integer.parseInt(relationId));
    	System.out.println("ֵΪ��    "+i);
    	String m = String.valueOf(i);
    	nickname = relationId;
    	
    	
    	System.out.println("��½id��   "+nickname);
        this.session = session;
        webSocketSet.add(this);     //����set��
//        clients.put(m, session);
        System.out.println("��ǰ��������Ϊ��    "+   m);
        onlineList();  
        lixian(nickname);
        String message = String.format("* %s %s", nickname, "has joined.");  
        addOnlineCount();           //��������1
//        broadcast(message); 
        System.out.println("�������Ӽ��룡��ǰ��������Ϊ" + getOnlineCount());
        
        String id = ChatUserMvc.getInstance().fanhuizaixian();
        String str[] = id.split("/");
        for(int a = 0;a < str.length;a++) {
        	String haoyou = ChatUserMvc.getInstance().gethaoyouid(Integer.parseInt(str[a]));
        	System.out.println("����Ϊ��   "+haoyou);
        	if(haoyou == null) {
        		System.out.println("��tm��û�к���"+nickname);
        	}else {
        		String[] aStrings  = haoyou.split(",");
        		for(int n = 0;n < aStrings.length;n++) {
        			   for(ChatAnnotation item: webSocketSet){             
        		            try {
        		            	
        		            	if (item.nickname.equals(aStrings[n]) ){
        						
        					     item.sendMessage(nickname);
        					
        		            	}
        		            } catch (IOException e) {
        		                e.printStackTrace();
        		                continue;
        		           }
        		        }
        		}
        	}
        	
        	
        	
        }
        
        
    }
     
    /**
     * ���ӹرյ��õķ���
     * @throws DAOException 
     */
    @OnClose
    public void onClose() throws DAOException{
        webSocketSet.remove(this);  //��set��ɾ��
        subOnlineCount();           //��������1    
        ChatUserMvc.getInstance().deleteChatUser(nickname);
//        String id = ChatUserMvc.getInstance().fanhuizaixian();
//        String str[] = id.split("/");
//        for(int m = 0;m < str.length;m++) {
        	String haoyou = ChatUserMvc.getInstance().gethaoyouid(Integer.parseInt(nickname));
        	if(haoyou.equals("null")) {
        		System.out.println("��tm��û�к���"+nickname);
        	}else {
        		String[] aStrings  = haoyou.split(",");
        		for(int n = 0;n < aStrings.length;n++) {
        			   for(ChatAnnotation item: webSocketSet){             
        		            try {
        		            	
        		            	if (item.nickname.equals(aStrings[n]) ){
        						
        					     item.sendMessage(nickname);
        					
        		            	}
        		            } catch (IOException e) {
        		                e.printStackTrace();
        		                continue;
        		           }
        		        }
        		}
        	}
        
        ChatUserMvc.getInstance().updatalixian(Integer.parseInt(nickname));
        
//        System.out.println("��һ���ӹرգ���ǰ����id" + id);
        System.out.println("��һ���ӹرգ���ǰ��������Ϊ" + getOnlineCount());
    }
     
    /**
     * �յ��ͻ�����Ϣ����õķ���
     * @param message �ͻ��˷��͹�������Ϣ
     * @param session ��ѡ�Ĳ���
     * @throws IOException 
     * @throws DAOException 
     */
    @OnMessage
    public void onMessage(String message, Session session) throws IOException, DAOException {
        System.out.println("���Կͻ��˵���Ϣ:" + message);
        
       
        
        Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		
		int i = -1;
		String time = df.format(date);
		
		String str[] = message.split("pIN1j0fd");
		
        System.out.println(str[0]);
        System.out.println(str[1]);
        ChatUserMvc.getInstance().insertMessage(nickname, str[1], time);
//        ��������
        
        
        
        
        
        
        
        for(ChatAnnotation item1: webSocketSet) {
           	if (item1.nickname.equals(str[0])) {
   				i = 1;
   			}
          }
    
        System.out.println(i);
        
        
        
        if(i == 1) {
        	
        for(ChatAnnotation item: webSocketSet){             
            try {
            	
            	if (item.nickname.equals(str[0]) ){
				
			     item.sendMessage(nickname+"pIN1j0fd"+str[1]);
			
            	}
            } catch (IOException e) {
                e.printStackTrace();
                continue;
           }
        }
        } else 
        {
        	ChatUserMvc.getInstance().insertLiXianmessage(Integer.parseInt(nickname), Integer.parseInt(str[0]), "pIN1j0fd"+str[1]);
//        	 for(ChatAnnotation item: webSocketSet){             
//                 try {
//                 	
//                	 if (item.nickname.equals(nickname) ){
//     				
//     			     item.sendMessage("�û�������..");
//     			
//                 	}
//                 } catch (IOException e) {
//                     e.printStackTrace();
//                     continue;
//                }
//		}
       }
        
        
        
//        System.out.println(clients.get("2"));
//        //��������
//        sendMessage(clients.get("2"), message);
      //  Ⱥ����Ϣ
//        for(ChatAnnotation item: webSocketSet){             
//            try {
//                item.sendMessage(nickname+":"+message);
//            } catch (IOException e) {
//                e.printStackTrace();
//                continue;
//           }
//       }
    }
     
    /**
     * ��������ʱ����
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error){
        System.out.println("��������");
        error.printStackTrace();
    }
    
 
    
    /**
     * ������������漸��������һ����û����ע�⣬�Ǹ����Լ���Ҫ���ӵķ�����
     * @param message
     * @throws IOException
     */
    public void sendMessage(String message) throws IOException{
        this.session.getBasicRemote().sendText(message);
        //this.session.getAsyncRemote().sendText(message);
    }
    
    public void sendMessage(java.util.Map<String, String> map) throws IOException, EncodeException{
        this.session.getBasicRemote().sendObject(map);
        //this.session.getAsyncRemote().sendText(message);
    }
    
    
    public void sendMessage(Session session,String message)throws IOException{
    	this.session.getBasicRemote().sendText(message);
    }
 
    public static synchronized int getOnlineCount() {
        return onlineCount;
    }
 
    public static synchronized void addOnlineCount() {
    	ChatAnnotation.onlineCount++;
    }
     
    public static synchronized void subOnlineCount() {
    	ChatAnnotation.onlineCount--;
    }
    
    private static void broadcast(String msg) {  
        for (ChatAnnotation client : webSocketSet) {  
            try {  
                synchronized (client) {  
                    client.session.getBasicRemote().sendText(msg);  
                }  
            } catch (IOException e) {  
            	webSocketSet.remove(client);  
                try {  
                    client.session.close();  
                } catch (IOException e1) {  
                    // Ignore  
                }  
                String message = String.format("* %s %s",  
                        client.nickname, "has been disconnected.");  
                broadcast(message);  
            }  
        }  
    }  
    
    private static void lixian(String nickname)throws IOException, NumberFormatException, DAOException, EncodeException{
    	
    	 if(ChatUserMvc.getInstance().findLiXian(Integer.parseInt(nickname))==1) {
    	String mString = 	ChatUserMvc.getInstance().getLiXian(Integer.parseInt(nickname));
    	String[] str = mString.split("/");
    	java.util.Map<String, String> map = new HashMap<>(); 
    	int  d = 0;
    	String b = null;
    	
    	 int i =  str.length;
    	 for(int m = 0;m < i; m++) {
    		 String[] s = str[m].split("pIN1j0fd");
    		 for (String key : map.keySet()) {
    	            if (key.equals(s[0])) {
						d = 1;
						b = map.get(key);
					}
    	            break;
    	        }
    		 
    		 if (d==1) {
				map.put(s[0], b+"pIN1j0fd"+s[1]);
			}else {
    		 map.put(s[0], s[1]);
			}
    	 }
    	 
    	 for(String key : map.keySet())
    	 {
    		 System.out.println("��ϢΪ��     "+map.get(key));
    	 }
    	 
    	 
//    	 System.out.println("������ϢΪ"+map.get(1));
    	 for (ChatAnnotation client : webSocketSet) {
    		 if(client.nickname.equals(nickname)) {
    			 client.sendMessage(map);
    		 }
              
         }  
//         ChatUserMvc.getInstance().removeLiXian(Integer.parseInt(nickname));
    	 }
    }
    
    private static void onlineList() throws IOException{  
        String online = "";  
        for (ChatAnnotation client : webSocketSet) {  
            if(online.equals("")){  
                online = client.nickname;  
            }else{  
                online += ","+client.nickname;  
            }  
        }  
//        String m = String.format("* %s %s", "��ǰ�����û�", online);  
//        for (ChatAnnotation client : webSocketSet) {  
//            client.session.getBasicRemote().sendText(m);  
//        }  
    }  
}